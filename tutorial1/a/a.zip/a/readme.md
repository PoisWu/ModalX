i wrote internation-hello-world.h. 
I did waht it need in fancy-hello-world, take the input name withe length limited(10 characters) and modify the output. the output the "output" 