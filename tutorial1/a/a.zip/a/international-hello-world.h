#ifndef INTERNATIONAL_HELLO_WORLD_H
#define INTERNATIONAL_HELLO_WORLD_H
void print_hello_string_int();
#endif